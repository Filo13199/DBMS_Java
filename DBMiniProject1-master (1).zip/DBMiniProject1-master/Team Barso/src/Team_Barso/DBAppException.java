package Team_Barso;

public class DBAppException extends Exception{
	public DBAppException(String errorMsg) {
		super(errorMsg);
	}
}
