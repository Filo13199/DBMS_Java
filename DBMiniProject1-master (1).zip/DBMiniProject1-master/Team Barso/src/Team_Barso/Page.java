package Team_Barso;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Vector;

public class Page  implements Serializable{
	 /**
	 * 
	 */
	private static final long serialVersionUID = -1530866107553881472L;
	Vector<LinkedHashMap<String,Object>> arrRecords = new Vector<>();
	
	 
}
