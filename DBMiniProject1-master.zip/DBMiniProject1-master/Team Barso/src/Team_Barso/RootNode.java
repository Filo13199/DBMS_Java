package Team_Barso;

import java.io.Serializable;

public class RootNode implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7591162671409087993L;
	String Path;
	public RootNode(String Path) {
		this.Path = Path;
	}
}
