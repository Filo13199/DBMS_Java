package Team_Barso;

import java.io.Serializable;

public class Tuple implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -1097906930121923126L;
	int Min;
	int Range;
}
